﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoidCohesion : AgentBehaviour
{
    public float neighbordist = 20;
    public List<GameObject> targets;

    public override Steering GetSteering() 
    {
        var steering = new Steering();

        var count = 0;

        foreach (var other in targets) //iterate through the group of objects
        {
            if (other != null) {
                var dist = (transform.position - other.transform.position).magnitude;
                if ((dist > 0) && (dist < neighbordist)) {
                    steering.linear += other.transform.position; // Add position
                    count++;
                }
            }
        }

        if (count > 0) //average the positions of all the objects
        {
            steering.linear /= count;
            steering.linear -= transform.position;
        }

        return steering;
    }
}
