﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AvoidAgent : AgentBehaviour
{
    public float collisionRadius = 5.0f;
    public List<GameObject> targets;

    public override Steering GetSteering() 
    {
        var steering = new Steering();
        var shortestTime = Mathf.Infinity;
        GameObject firstTarget = null;
        var firstMinSeparation = 0.0f;
        var firstDistance = 0.0f;
        var firstRelativePos = Vector3.zero;
        var firstRelativeVel = Vector3.zero;

        //Debug.Log("Targets in AvoidAgent: " + targets.Count);

        foreach (var t in targets) {
            Debug.Log(t);
            Vector3 relativePos;
            var targetAgent = t.GetComponent<Agent>();
            relativePos = t.transform.position - transform.position;
            //Debug.Log("Agent is: " + agent);
            //Debug.Log("Other agent is: " + targetAgent);
            var relativeVel = targetAgent.velocity - agent.velocity;
            var relativeSpeed = relativeVel.magnitude;
            var timeToCollision = Vector3.Dot(relativePos, relativeVel);
            timeToCollision /= relativeSpeed * relativeSpeed * -1;
            var distance = relativePos.magnitude;
            var minSeparation = distance - relativeSpeed * timeToCollision;

            if (minSeparation > 2 * collisionRadius) {
                continue;
            }

            if (timeToCollision > 0.0f && timeToCollision < shortestTime) {
                shortestTime = timeToCollision;
                firstTarget = t;
                firstMinSeparation = minSeparation;
                firstRelativePos = relativePos;
                firstRelativeVel = relativeVel;
            }
        }

        if (firstTarget == null) {
            return steering;
        }

        if (firstMinSeparation <= 0.0f || firstDistance < 2 * collisionRadius) {
            firstRelativePos = firstTarget.transform.position;
        } else {
            firstRelativePos += firstRelativeVel * shortestTime;
        }

        firstRelativePos.Normalize();
        steering.linear = -firstRelativePos * agent.maxAccel;
        return steering;
    }
}
