﻿﻿using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
/*
public class PathFollow : Seek
{
    public List<Path> path;
    public float radius = 5f;
    public float secondsAhead = 10f;

    public override void Start() 
    {
        base.Start();
        //target = new GameObject();
    }
    
    private void OnDestroy() 
    {
        Destroy(target);
    }
    
    public override Steering GetSteering() 
    {
        if (path.Count > 0) {
            var position = transform.position.To2D();
            var prediction = position + agent.velocity * secondsAhead;
            var minDist = Mathf.Infinity;

            //set a target
            for (var i = 0; i < path.Count - 1; ++i) {
                if (path[i].isPassed && path[i + 1].isPassed)
                    continue;

                var pointA = path[i].position;
                var pointB = path[i + 1].position;
                var closestPoint = ClosestPoint(prediction, pointA, pointB);

                if ((closestPoint.x < pointA.x || closestPoint.x > pointB.x) ||
                    (((closestPoint.y < pointA.y) && (closestPoint.y < pointB.y))
                     || ((closestPoint.y > pointA.y) && (closestPoint.y > pointB.y)))) {
                    closestPoint = (i < path.Count - 2) ? pointA : pointB;
                }

                var dist = math.distance(prediction, closestPoint);
                if (dist < minDist) {
                    minDist = dist;
                    target.transform.position = closestPoint.To3D();
                }
            }

            //update the path
            RecordPassedNodes(position);

            //keep the owner on the path
            if (math.distance(target.transform.position.To2D(), position) > radius) {
                return base.GetSteering();
            }
        }

        return new Steering();
    }

    private float2 ClosestPoint(float2 origin, float2 pointA, float2 pointB)
    {
        // CVector2D that points from pointA to origin
        var a2o = origin - pointA;
        // CVector2D that points from pointA to pointB
        var a2b = pointB - pointA;

        math.normalizesafe(a2b);
        a2b *= math.dot(a2o, a2b);

        return pointA + a2b;
    }

    private void RecordPassedNodes(float2 position)
    {
        var front = path[0];
        var back = path[path.Count - 1];
        var diameter = radius * 2f;
        
        if (math.distance(front.position, position) < diameter) {
            ResetPath();
            front.isPassed = true;
        }
        else if (math.distance(back.position, position) < diameter) {
            ResetPath();
            back.isPassed = true;
        } else {
            for (var i = 1; i < path.Count - 1; ++i){
                if (path[i].isPassed) 
                    continue;

                if (math.distance(path[i].position, position) < diameter) {
                    path[i].isPassed = true;
                }
            }
        }
    }

    private void ResetPath()
    {
        foreach (var node in path) {
            node.isPassed = false;
        }
    }
}*/