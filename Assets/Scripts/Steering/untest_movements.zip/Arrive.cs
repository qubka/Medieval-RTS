﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrive : AgentBehaviour
{

    public float targetRadius = 5.0f;
    public float slowRadius = 15.0f;
    public float timeToTarget = 0.1f;

    public override Steering GetSteering() 
    {
        var steering = new Steering();
        var direction = target.transform.position - transform.position;
        var distance = direction.magnitude;
        float targetSpeed;

        if (distance < targetRadius) { //if we are far away, do nothing
            return steering;
        }

        if(distance > slowRadius) { //proceed at maxspeed
            targetSpeed = agent.maxSpeed;
        } else {
            targetSpeed = agent.maxSpeed * distance / slowRadius;
        }

        var desiredVelocity = direction;
        desiredVelocity.Normalize();
        desiredVelocity *= targetSpeed;
        steering.linear = desiredVelocity - agent.velocity;
        steering.linear /= timeToTarget;

        if (steering.linear.magnitude > agent.maxAccel) {
            steering.linear.Normalize();
            steering.linear *= agent.maxAccel;
        }
        return steering;
    }
}
