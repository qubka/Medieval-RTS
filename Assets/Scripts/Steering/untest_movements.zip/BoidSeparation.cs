﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoidSeparation : Flee
{
    public float desiredseparation = 15.0f;
    public List<GameObject> targets;

    public override Steering GetSteering() 
    {
        var steering = new Steering();
        var count = 0;

        // For every boid in the system, check if it's too close
        foreach (var other in targets) {
            if (other != null) {
                var dist = (transform.position - other.transform.position).magnitude;

                // If the distance is greater than 0 and less than an arbitrary amount (0 when you are yourself)
                if ((dist > 0) && (dist < desiredseparation)) {
                    // Calculate vector pointing away from neighbor
                    var diff = transform.position - other.transform.position;
                    diff.Normalize();
                    diff /= dist; // Weight by distance
                    steering.linear += diff;
                    count++; // Keep track of how many
                }
            }
        }

        // Average -- divide by how many
        if (count > 0) {
            //steering.linear /= (float)count;
        }

        return steering;
    }
}
