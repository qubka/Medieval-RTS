﻿using UnityEngine;
using System.Collections;
public class Flee : AgentBehaviour
{
    //go in opposite direction from target
    public override Steering GetSteering() 
    {
        var steering = new Steering { linear = transform.position - target.transform.position };
        steering.linear.Normalize();
        steering.linear *= agent.maxAccel;
        return steering;
    }
}