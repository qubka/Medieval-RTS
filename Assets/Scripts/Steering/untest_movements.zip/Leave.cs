﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Leave : AgentBehaviour
{
    public float escapeRadius;
    public float dangerRadius;
    public float timeToTarget = 0.1f;

    public override Steering GetSteering() 
    {
        var steering = new Steering();
        var direction = transform.position - target.transform.position;
        var distance = direction.magnitude;
        if (distance > dangerRadius)
            return steering;
       
        float reduce;
        if (distance < escapeRadius) {
            reduce = 0f;
        } else {
            reduce = distance / dangerRadius * agent.maxSpeed;
        }

        var targetSpeed = agent.maxSpeed - reduce;

        var desiredVelocity = direction;
        desiredVelocity.Normalize();
        desiredVelocity *= targetSpeed;
        steering.linear = desiredVelocity - agent.velocity;
        steering.linear /= timeToTarget;

        if (steering.linear.magnitude > agent.maxAccel) {
            steering.linear.Normalize();
            steering.linear *= agent.maxAccel;
        }

        return steering;
    }
}
